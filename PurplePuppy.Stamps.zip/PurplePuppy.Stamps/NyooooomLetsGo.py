import sys
import subprocess
import json
from pathlib import Path

def install_or_update_dependencies(dependencies):
    """Install or update the required dependencies using pip."""
    try:
        # Upgrade pip to the latest version
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
        print("Successfully updated pip.")
    except subprocess.CalledProcessError:
        print("Failed to update pip.")

    for dep in dependencies:
        try:
            # Install or upgrade the dependency
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", dep])
            print(f"Successfully installed or updated {dep}.")
        except subprocess.CalledProcessError:
            print(f"Failed to install or update {dep}.")

def ensure_path_exists(path):
    """Ensure a path exists; throw an error if not."""
    if not path.exists():
        raise FileNotFoundError("Put the mod folder in the right path first silly: WEBFISHING/GDWeave/mods/")

def main():
    # List of dependencies
    dependencies = [
        "numpy",
        "opencv-python",
        "Pillow",
        "tqdm",
        "PySide6"  # Added PySide6 to the dependencies list
    ]
    install_or_update_dependencies(dependencies)

    # Locate Python executable
    python_path = sys.executable.replace("\\", "/")  # Use forward slashes for cross-platform compatibility
    print(f"Python executable located at: {python_path}")

    # Define and verify required paths
    current_dir = Path(__file__).resolve().parent  # PurplePuppy.Stamps directory
    mods_dir = current_dir.parent  # mods directory
    gdweave_dir = mods_dir.parent  # GDWeave directory
    configs_dir = gdweave_dir / "configs"  # Target configs folder

    # Ensure the directory structure exists
    ensure_path_exists(mods_dir)
    ensure_path_exists(gdweave_dir)
    ensure_path_exists(configs_dir)

    # Target JSON file
    config_file = configs_dir / "purplepuppy.stamps.json"

    # Create or overwrite the JSON file
    config_data = {
        "python_path": python_path,
        "img": False
    }

    try:
        with config_file.open("w") as f:
            json.dump(config_data, f, indent=4)
        print(f"Configuration file successfully updated at: {config_file}")
    except Exception as e:
        print(f"Failed to create or update the JSON file: {e}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An error occurred: {e}")
        input("Press Enter to exit...")
        sys.exit(1)
