import os
import sys
import random
import numpy as np
import cv2
from PIL import Image, UnidentifiedImageError, ImageGrab
import shutil

# Ensure required libraries are installed
def check_dependencies():
    """
    Checks for required dependencies and raises ImportError if any are missing.
    """
    missing_modules = []
    try:
        import PIL
    except ImportError:
        missing_modules.append('Pillow')
    try:
        import numpy
    except ImportError:
        missing_modules.append('numpy')
    try:
        import cv2
    except ImportError:
        missing_modules.append('opencv-python')

    if missing_modules:
        message = "Error: Missing dependencies:\n"
        for module in missing_modules:
            message += f"- {module}\n"
        message += "Please install them using `pip install module_name`"
        raise ImportError(message)

check_dependencies()

# Create a registry dictionary
processing_method_registry = {}

def register_processing_method(name, default_params=None):
    """
    Decorator to register a processing method.
    """
    def decorator(func):
        func.default_params = default_params or {}
        processing_method_registry[name] = func
        return func
    return decorator

def prepare_image(img):
    """
    Converts image to RGBA if not already, and returns a writable copy of the image.
    """
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    # Make a writable copy of the image
    img = img.copy()
    return img

def preprocess_image(image, color_key_array, params=None):
    """
    Preprocesses the image to enhance gradients, expand the color range,
    and improve overall image quality for better processing results.
    
    Parameters:
    - image: Input image as a NumPy array (H, W, C).
    - color_key_array: List of dictionaries with color information to boost.
    - params: Dictionary of parameters to control preprocessing steps.
    """
    # === Default Parameters ===
    default_params = {
        'alpha_threshold': 191,      # Process pixels with alpha > 191 (75% opacity)
    	'clahe_clip_limit': 4.0,     # Increase contrast enhancement
    	'clahe_grid_size': 8,        # Grid size suitable for 200x200 images
    	'saturation_boost': 1.5,     # Stronger boost for target colors
    	'unsharp_strength': 1.5,     # Enhance edges more aggressively
    	'unsharp_radius': 1.0,       # Radius for unsharp masking
    	'gamma_correction': 0.9,     # Slightly brighten the image
    	'contrast_percentiles': (1, 99),  # More aggressive contrast stretching
    	'global_saturation_boost': 1.2,   # Increase overall saturation
    }
    if params is None:
        params = {}
    # Merge default parameters with user-provided parameters
    params = {**default_params, **params}
    # ==============================

    # Check if the image has an alpha channel
    has_alpha = image.shape[2] == 4
    if has_alpha:
        alpha_channel = image[:, :, 3]
        rgb_image = image[:, :, :3]
    else:
        alpha_channel = None
        rgb_image = image

    # Create a mask to select only fully opaque pixels
    if has_alpha:
        opaque_mask = alpha_channel >= params['alpha_threshold']
    else:
        opaque_mask = np.ones_like(rgb_image[:, :, 0], dtype=bool)

    # Prepare the RGB image for processing
    rgb_image_uint8 = rgb_image.astype(np.uint8).copy()

    # === Global Contrast Stretching ===
    # Apply only to opaque pixels
    for c in range(3):  # For each color channel
        channel = rgb_image_uint8[:, :, c]
        # Compute percentiles only on opaque pixels
        lower_percentile, upper_percentile = params['contrast_percentiles']
        min_val = np.percentile(channel[opaque_mask], lower_percentile)
        max_val = np.percentile(channel[opaque_mask], upper_percentile)
        # Avoid division by zero
        if max_val - min_val == 0:
            continue
        # Stretch the histogram
        channel = np.clip((channel - min_val) * (255 / (max_val - min_val)), 0, 255).astype(np.uint8)
        rgb_image_uint8[:, :, c] = channel
    # ==============================

    # === Gamma Correction ===
    gamma = params['gamma_correction']
    if gamma != 1.0:
        invGamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** invGamma) * 255 for i in np.arange(256)]).astype("uint8")
        rgb_image_uint8 = cv2.LUT(rgb_image_uint8, table)
    # ==============================

    # === Unsharp Masking ===
    unsharp_strength = params['unsharp_strength']
    if unsharp_strength > 0:
        blurred = cv2.GaussianBlur(rgb_image_uint8, (0, 0), params['unsharp_radius'])
        sharpened = cv2.addWeighted(rgb_image_uint8, 1 + unsharp_strength, blurred, -unsharp_strength, 0)
        rgb_image_uint8 = sharpened
    # ==============================

    # === Apply CLAHE to the L channel in LAB color space ===
    lab_image = cv2.cvtColor(rgb_image_uint8, cv2.COLOR_RGB2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab_image)

    clahe = cv2.createCLAHE(clipLimit=params['clahe_clip_limit'], 
                            tileGridSize=(params['clahe_grid_size'], params['clahe_grid_size']))
    l_channel_clahe = clahe.apply(l_channel)

    lab_image = cv2.merge((l_channel_clahe, a_channel, b_channel))
    rgb_image_uint8 = cv2.cvtColor(lab_image, cv2.COLOR_LAB2RGB)
    # ==============================

    # === Global Saturation Boost ===
    hsv_image = cv2.cvtColor(rgb_image_uint8, cv2.COLOR_RGB2HSV).astype(np.float32)
    hsv_image[:, :, 1] *= params['global_saturation_boost']
    hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1], 0, 255)
    rgb_image_uint8 = cv2.cvtColor(hsv_image.astype(np.uint8), cv2.COLOR_HSV2RGB)
    # ==============================

    # === Selective Color Boosting ===
    hsv_image = cv2.cvtColor(rgb_image_uint8, cv2.COLOR_RGB2HSV)
    h = hsv_image[:, :, 0].astype(np.float32)
    s = hsv_image[:, :, 1].astype(np.float32)
    v = hsv_image[:, :, 2].astype(np.float32)

    for color_key in color_key_array:
        hex_code = color_key['hex'].lstrip('#')
        color_rgb = tuple(int(hex_code[i:i + 2], 16) for i in (0, 2, 4))
        boost = color_key.get('boost', params['saturation_boost'])
        threshold = color_key.get('threshold', 20)  # Default threshold

        # Convert target color to HSV
        color_hsv = cv2.cvtColor(np.uint8([[color_rgb]]), cv2.COLOR_RGB2HSV)[0, 0]
        target_h = color_hsv[0]
        target_s = color_hsv[1]

        # Calculate hue and saturation difference
        hue_diff = np.abs(h - target_h)
        hue_diff = np.minimum(hue_diff, 180 - hue_diff)  # Handle hue wrap-around

        sat_diff = np.abs(s - target_s)

        # Create a mask for pixels close to the target color
        color_mask = (hue_diff < threshold) & opaque_mask

        # Adjust saturation
        s = np.where(color_mask, np.clip(s * boost, 0, 255), s)

    # Convert back to RGB
    hsv_image[:, :, 1] = s
    rgb_image_uint8 = cv2.cvtColor(hsv_image.astype(np.uint8), cv2.COLOR_HSV2RGB)
    # ==============================

    # Restore the original RGB values for non-opaque pixels
    if has_alpha:
        rgb_image_uint8[~opaque_mask] = rgb_image[~opaque_mask]

    # Convert back to RGBA if alpha channel was present
    if has_alpha:
        preprocessed_image = np.dstack((rgb_image_uint8, alpha_channel))
    else:
        preprocessed_image = rgb_image_uint8

    return preprocessed_image

def resize_image(img, target_size):
    """
    Resizes the image to the target size while maintaining aspect ratio.
    Handles the alpha channel separately to prevent artifacting.
    """
    try:
        width, height = img.size
        scale_factor = target_size / float(max(width, height))
        new_width = max(1, int(width * scale_factor))
        new_height = max(1, int(height * scale_factor))

        # Separate the alpha channel
        if img.mode == 'RGBA':
            img_no_alpha = img.convert('RGB')
            alpha = img.getchannel('A')

            # Resize RGB and alpha channels separately
            img_no_alpha = img_no_alpha.resize((new_width, new_height), resample=Image.LANCZOS)
            alpha = alpha.resize((new_width, new_height), resample=Image.LANCZOS)

            # Merge back together
            img = Image.merge('RGBA', (*img_no_alpha.split(), alpha))
        else:
            img = img.resize((new_width, new_height), resample=Image.LANCZOS)

        return img
    except Exception as e:
        raise RuntimeError(f"Failed to resize the image: {e}")

def find_closest_color(pixel, color_key):
    """
    Finds the closest color in the color_key to the given pixel.
    """
    pixel = np.array(pixel)  # Convert the pixel tuple to a NumPy array
    colors = np.array(list(color_key.values()))  # Extract color values as NumPy arrays
    color_nums = list(color_key.keys())  # Extract corresponding keys

    # Calculate Euclidean distances to each color in the color_key
    distances = np.sqrt(np.sum((colors - pixel) ** 2, axis=1))
    idx = np.argmin(distances)  # Get the index of the closest color
    closest_color_num = color_nums[idx]  # Find the key of the closest color

    return closest_color_num

def process_image(img, color_key, process_mode, process_params):
    """
    Dispatches image processing to the appropriate method based on process_mode.
    """
    # Make a copy of the image to ensure it's writable
    img = img.copy()

    if process_mode in processing_method_registry:
        processing_function = processing_method_registry[process_mode]
        return processing_function(img, color_key, process_params)
    else:
        # Default to color matching if unknown process_mode
        return color_matching(img, color_key, process_params)

# Individual processing methods

@register_processing_method('color_matching', default_params={})
def color_matching(img, color_key, params):
    """
    Maps each pixel to the closest color in the color_key without dithering.
    """
    img = img.copy()
    width, height = img.size
    pixels = img.load()
    has_alpha = img.mode == 'RGBA'

    for y in range(height):
        for x in range(width):
            old_pixel = pixels[x, y]
            if has_alpha and old_pixel[3] <= 191:
                continue  # Skip pixels with alpha <= 191
            new_pixel_num = find_closest_color(old_pixel[:3], color_key)
            new_pixel = color_key[new_pixel_num]
            if has_alpha:
                pixels[x, y] = new_pixel + (old_pixel[3],)
            else:
                pixels[x, y] = new_pixel
    return img

@register_processing_method('floyd_steinberg', default_params={'strength': 1.0})
def floyd_steinberg_dithering(img, color_key, params):
    """
    Applies Floyd-Steinberg dithering to the image.
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    diffusion_matrix = [
        (1, 0, 7 / 16),
        (-1, 1, 3 / 16),
        (0, 1, 5 / 16),
        (1, 1, 1 / 16),
    ]
    return error_diffusion_dithering(img, color_key, strength, diffusion_matrix)

@register_processing_method('jarvis_judice_ninke', default_params={'strength': 1.0})
def jarvis_judice_ninke_dithering(img, color_key, params):
    """
    Applies Jarvis-Judice-Ninke dithering to the image.
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    diffusion_matrix = [
        (1, 0, 7 / 48), (2, 0, 5 / 48),
        (-2, 1, 3 / 48), (-1, 1, 5 / 48), (0, 1, 7 / 48), (1, 1, 5 / 48), (2, 1, 3 / 48),
        (-2, 2, 1 / 48), (-1, 2, 3 / 48), (0, 2, 5 / 48), (1, 2, 3 / 48), (2, 2, 1 / 48),
    ]
    return error_diffusion_dithering(img, color_key, strength, diffusion_matrix)

@register_processing_method('atkinson', default_params={'strength': 1.0})
def atkinson_dithering(img, color_key, params):
    """
    Applies Atkinson dithering to the image.
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    diffusion_matrix = [
        (1, 0, 1 / 8), (2, 0, 1 / 8),
        (-1, 1, 1 / 8), (0, 1, 1 / 8), (1, 1, 1 / 8),
        (0, 2, 1 / 8),
    ]
    return error_diffusion_dithering(img, color_key, strength, diffusion_matrix)

@register_processing_method('stucki', default_params={'strength': 1.0})
def stucki_dithering(img, color_key, params):
    """
    Applies Stucki dithering to the image.
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    diffusion_matrix = [
        (1, 0, 8 / 42), (2, 0, 4 / 42),
        (-2, 1, 2 / 42), (-1, 1, 4 / 42), (0, 1, 8 / 42), (1, 1, 4 / 42), (2, 1, 2 / 42),
        (-2, 2, 1 / 42), (-1, 2, 2 / 42), (0, 2, 4 / 42), (1, 2, 2 / 42), (2, 2, 1 / 42),
    ]
    return error_diffusion_dithering(img, color_key, strength, diffusion_matrix)

@register_processing_method('light_dither', default_params={'strength': 1.0})
def pixel_art_dithering(img, color_key, params):
    """
    Applies a custom dithering method optimized for small art
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    diffusion_matrix = [
        (1, 0, 0.4),
        (-1, 1, 0.2),
        (0, 1, 0.2),
        (1, 1, 0.2),
    ]
    return error_diffusion_dithering(img, color_key, strength, diffusion_matrix)


@register_processing_method('random', default_params={'strength': 1.0})
def random_dithering(img, color_key, params):
    """
    Applies random dithering to the image.
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    width, height = img.size
    pixels = img.load()
    has_alpha = img.mode == 'RGBA'

    noise_intensity = int(64 * strength)
    for y in range(height):
        for x in range(width):
            old_pixel = pixels[x, y]
            if has_alpha and old_pixel[3] == 0:
                continue
            noisy_pixel = tuple(
                min(max(c + random.randint(-noise_intensity, noise_intensity), 0), 255)
                for c in old_pixel[:3]
            )
            new_pixel_num = find_closest_color(noisy_pixel, color_key)
            new_pixel = color_key[new_pixel_num]
            if has_alpha:
                pixels[x, y] = new_pixel + (old_pixel[3],)
            else:
                pixels[x, y] = new_pixel
    return img

@register_processing_method('line_art', default_params={'line_style': 'black_on_white', 'edge_threshold': 50})
def line_art(img, color_key, params):
    """
    Converts the image into black and white line art.

    Parameters:
    - line_style (str): 'black_on_white' or 'white_on_black' to specify the line and background colors.
    - edge_threshold (int): Threshold for edge detection (0-255). Lower values detect more edges.
    """
    line_style = params.get('line_style', 'black_on_white')
    edge_threshold = params.get('edge_threshold', 50)

    img = img.convert('L')  # Convert image to grayscale
    width, height = img.size
    pixels = img.load()

    # Edge detection using the Sobel operator
    sobel_x = [[-1, 0, 1],
               [-2, 0, 2],
               [-1, 0, 1]]

    sobel_y = [[-1, -2, -1],
               [0,  0,  0],
               [1,  2,  1]]

    edge_img = Image.new('L', (width, height))
    edge_pixels = edge_img.load()

    for y in range(1, height - 1):
        for x in range(1, width - 1):
            gx = 0
            gy = 0
            for ky in range(-1, 2):
                for kx in range(-1, 2):
                    pixel = pixels[x + kx, y + ky]
                    gx += pixel * sobel_x[ky + 1][kx + 1]
                    gy += pixel * sobel_y[ky + 1][kx + 1]
            magnitude = int((gx**2 + gy**2)**0.5)
            edge_pixels[x, y] = magnitude

    # Thresholding to create binary image
    for y in range(height):
        for x in range(width):
            edge_value = edge_pixels[x, y]
            if edge_value > edge_threshold:
                edge_pixels[x, y] = 255  # Edge pixel
            else:
                edge_pixels[x, y] = 0  # Non-edge pixel

    # Create final line art image
    line_art_img = Image.new('RGBA', (width, height))
    line_art_pixels = line_art_img.load()

    # Define line and background colors based on line_style
    if line_style == 'black_on_white':
        line_color = (0, 0, 0, 255)
        background_color = (255, 255, 255, 255)
    elif line_style == 'white_on_black':
        line_color = (255, 255, 255, 255)
        background_color = (0, 0, 0, 255)
    else:
        # Default to black on white if invalid option
        line_color = (0, 0, 0, 255)
        background_color = (255, 255, 255, 255)

    # Map edge image to line art image
    for y in range(height):
        for x in range(width):
            if edge_pixels[x, y] == 255:
                line_art_pixels[x, y] = line_color  # Line pixel
            else:
                line_art_pixels[x, y] = background_color  # Background pixel

    # Map colors to color_key
    # First, create a simplified color_key for black and white
    if line_style == 'black_on_white':
        color_mapping = {
            (0, 0, 0): find_closest_color((0, 0, 0), color_key),        # Black lines
            (255, 255, 255): find_closest_color((255, 255, 255), color_key)  # White background
        }
    else:
        color_mapping = {
            (255, 255, 255): find_closest_color((255, 255, 255), color_key),  # White lines
            (0, 0, 0): find_closest_color((0, 0, 0), color_key)        # Black background
        }

    # Apply color mapping
    for y in range(height):
        for x in range(width):
            pixel = line_art_pixels[x, y][:3]
            color_num = color_mapping.get(pixel)
            new_pixel = color_key[color_num]
            line_art_pixels[x, y] = new_pixel + (255,)

    return line_art_img

@register_processing_method('blue_noise', default_params={'strength': 1.0})
def blue_noise_dithering(img, color_key, params):
    """
    Applies blue noise dithering to the image.
    """
    strength = params.get('strength', 1.0)

    img = img.copy()
    width, height = img.size
    pixels = img.load()
    has_alpha = img.mode == 'RGBA'

    script_dir = os.path.dirname(os.path.abspath(__file__))
    blue_noise_path = os.path.join(script_dir, 'blue_noise.png')
    try:
        blue_noise = Image.open(blue_noise_path).convert('L')
        bn_width, bn_height = blue_noise.size
        bn_pixels = blue_noise.load()
        for y in range(height):
            for x in range(width):
                old_pixel = pixels[x, y]
                if has_alpha and old_pixel[3] == 0:
                    continue
                noise = (bn_pixels[x % bn_width, y % bn_height] / 255.0 - 0.5) * 2  # Range -1 to 1
                noise *= 64 * strength  # Adjust noise intensity
                noisy_pixel = tuple(
                    min(max(c + noise, 0), 255) for c in old_pixel[:3]
                )
                new_pixel_num = find_closest_color(noisy_pixel, color_key)
                new_pixel = color_key[new_pixel_num]
                if has_alpha:
                    pixels[x, y] = new_pixel + (old_pixel[3],)
                else:
                    pixels[x, y] = new_pixel
    except FileNotFoundError:
        # If blue_noise.png is not found, proceed without blue noise dithering
        if params.get('message_callback'):
            params['message_callback']("Blue noise pattern not found. Skipping blue noise dithering.")
    return img

# Helper functions

def error_diffusion_dithering(img, color_key, strength, diffusion_matrix):
    """
    Generic function for error diffusion dithering algorithms.
    """
    width, height = img.size
    pixels = img.load()
    has_alpha = img.mode == 'RGBA'

    for y in range(height):
        for x in range(width):
            old_pixel = pixels[x, y]
            if has_alpha and old_pixel[3] == 0:
                continue  # Skip transparent pixels
            old_pixel_rgb = pixels[x, y][:3]
            new_pixel_num = find_closest_color(old_pixel_rgb, color_key)
            new_pixel = color_key[new_pixel_num]

            # Calculate quantization error
            quant_error = tuple((old - new) * strength for old, new in zip(old_pixel_rgb, new_pixel))

            # Update the pixel
            if has_alpha:
                pixels[x, y] = new_pixel + (old_pixel[3],)
            else:
                pixels[x, y] = new_pixel

            # Distribute the error
            distribute_error(pixels, x, y, width, height, quant_error, diffusion_matrix)
    return img

def distribute_error(pixels, x, y, width, height, quant_error, diffusion_matrix):
    """
    Distributes the quantization error to neighboring pixels.
    """
    for dx, dy, coefficient in diffusion_matrix:
        nx, ny = x + dx, y + dy
        if 0 <= nx < width and 0 <= ny < height:
            current_pixel = list(pixels[nx, ny])
            has_alpha = len(current_pixel) == 4
            if has_alpha and current_pixel[3] == 0:
                continue  # Skip transparent pixels

            # Apply the error
            for i in range(3):  # R, G, B channels
                current_pixel[i] += quant_error[i] * coefficient
                current_pixel[i] = int(min(max(current_pixel[i], 0), 255))

            pixels[nx, ny] = tuple(current_pixel)


def process_and_save_image(img, target_size, process_mode, process_params, color_key_array, preprocess_flag, progress_callback=None, message_callback=None, error_callback=None):
    """
    Processes and saves the image according to specified parameters.
    """
    try:
        script_directory = os.path.dirname(os.path.abspath(__file__))

        if message_callback:
            message_callback("Preparing image...")

        # Prepare the image (convert to RGBA if needed)
        img = prepare_image(img)

        # Resize the image if needed
        if target_size is not None:
            img = resize_image(img, target_size)
            if message_callback:
                message_callback(f"Image resized to {img.size}")
        else:
            if message_callback:
                message_callback("Keeping original image dimensions.")

        # Preprocess the image if needed
        if preprocess_flag:
            img_np = np.array(img)
            img_np = preprocess_image(img_np, color_key_array)
            if message_callback:
                message_callback("Image preprocessed.")
            img = Image.fromarray(img_np, 'RGBA')

        # Construct color_key from color_key_array
        color_key = {}
        for item in color_key_array:
            color_num = item['number']
            hex_code = item['hex'].lstrip('#')
            rgb = tuple(int(hex_code[i:i+2], 16) for i in (0, 2, 4))
            color_key[color_num] = rgb

        # Process the image
        img = process_image(img, color_key, process_mode, process_params)
        if message_callback:
            message_callback(f"Processing applied: {process_mode}")

        # Save a preview of the processed image in 'preview' folder
        preview_folder = create_and_clear_preview_folder(message_callback)

        # Save preview image
        preview_path = os.path.join(preview_folder, 'preview.png')
        img.save(preview_path)
        if message_callback:
            message_callback(f"Preview saved at: {preview_path}")

        # Now process and save the image data
        width, height = img.size
        scaled_width = round(width * 0.1, 1)
        scaled_height = round(height * 0.1, 1)

        # Default output path
        output_file_path = os.path.join(script_directory, "stamp.txt")

        with open(output_file_path, 'w') as f:
            # Write the first line with scaled width, height, and 'img'
            f.write(f"{scaled_width},{scaled_height},img\n")
            if message_callback:
                message_callback(f"Scaled dimensions written: {scaled_width},{scaled_height},img")

            # Process each pixel
            pixels = img.load()

            if pixels is None:
                raise ValueError("Failed to load image pixels. The image may be corrupted or unsupported.")

            for y in range(height - 1, -1, -1):
                for x in range(width):
                    try:
                        pixel = pixels[x, y]

                        # Handle both RGB and RGBA images
                        if len(pixel) == 4:  # RGBA
                            r, g, b, a = pixel
                        elif len(pixel) == 3:  # RGB
                            r, g, b = pixel
                            a = 255  # Assume fully opaque
                        else:
                            raise ValueError(f"Unexpected pixel format at ({x}, {y}): {pixel}")

                        if a <= 191:  # Skip pixels with alpha <= 191 (75% opacity)
                            continue

                        # Map the pixel to the closest color
                        closest_color_num = find_closest_color((r, g, b), color_key)

                        # Scale the coordinates
                        scaled_x = round(x * 0.1, 1)
                        scaled_y = round((height - 1 - y) * 0.1, 1)

                        # Write to the file
                        f.write(f"{scaled_x},{scaled_y},{closest_color_num}\n")

                    except Exception as e:
                        if message_callback:
                            message_callback(f"Error processing pixel at ({x}, {y}): {e}")

        if message_callback:
            message_callback(f"Processing complete! Output saved to: {output_file_path}")

    except Exception as e:
        if error_callback:
            error_callback(f"An error occurred: {e}")


def process_and_save_gif(image_path, target_size, process_mode, process_params, color_key_array, preprocess_flag,
                         progress_callback=None, message_callback=None, error_callback=None):
    """
    Processes and saves an animated image (GIF or WebP) according to specified parameters.
    """
    try:
        script_directory = os.path.dirname(os.path.abspath(__file__))

        # Open frames.txt and clear its contents
        frames_txt_path = os.path.join(script_directory, 'frames.txt')
        with open(frames_txt_path, 'w') as frames_file:
            pass  # Clears the file

        # Open the image
        img = Image.open(image_path)
        if not getattr(img, "is_animated", False):
            if message_callback:
                message_callback("Selected file is not an animated image with multiple frames.")
            img.close()
            return

        total_frames = img.n_frames
        if message_callback:
            message_callback(f"Total frames in image: {total_frames}")

        # Gather delays for each frame
        delays = []
        for frame_number in range(total_frames):
            img.seek(frame_number)
            delay = img.info.get('duration', 100)  # Default to 100ms if not specified
            delays.append(delay)

        # Determine delay uniformity
        uniform_delay = delays[0] if all(d == delays[0] for d in delays) else -1

        # Save frames to 'Frames' directory (and clear it first)
        save_frames(img, target_size, process_mode, process_params, preprocess_flag, color_key_array,
                    progress_callback, message_callback, error_callback)

        # Create and clear 'preview' folder
        preview_folder = create_and_clear_preview_folder(message_callback)

        # Now process frames and write to frames.txt
        # Load the first frame
        script_directory = os.path.dirname(os.path.abspath(__file__))
        first_frame_path = os.path.join(script_directory, 'Frames', 'frame_1.png')

        if not os.path.exists(first_frame_path):
            if error_callback:
                error_callback(f"First frame not found at {first_frame_path}")
            img.close()
            return

        # Construct color_key from color_key_array
        color_key = {}
        for item in color_key_array:
            color_num = item['number']
            hex_code = item['hex'].lstrip('#')
            rgb = tuple(int(hex_code[i:i + 2], 16) for i in (0, 2, 4))
            color_key[color_num] = rgb

        # Process first frame and write to stamp.txt
        with Image.open(first_frame_path) as first_frame:
            width, height = first_frame.size
            scaled_width = round(width * 0.1, 1)  # Multiply by 0.1
            scaled_height = round(height * 0.1, 1)  # Multiply by 0.1

            # Write header to stamp.txt
            stamp_txt_path = os.path.join(script_directory, 'stamp.txt')
            with open(stamp_txt_path, 'w') as stamp_file:
                stamp_file.write(f"{scaled_width},{scaled_height},gif,{total_frames},{uniform_delay}\n")
                if message_callback:
                    message_callback(f"Header written to stamp.txt: {scaled_width},{scaled_height},gif,{total_frames},{uniform_delay}")

                # Initialize Frame1Array and store the first frame's pixels
                Frame1Array = {}  # Dictionary to store pixels as {(x, y): color_num}
                first_frame_pixels = {}  # Store for looping comparison

                pixels = first_frame.load()
                for y in range(height):
                    for x in range(width):
                        pixel = pixels[x, y]
                        if len(pixel) == 4:  # RGBA
                            r, g, b, a = pixel
                            if a <= 191:
                                continue  # Skip pixels with alpha <= 191
                        else:
                            r, g, b = pixel
                            a = 255  # Assume fully opaque
                            if a <= 191:
                                continue  # Skip pixels with alpha <= 191

                        # Map the pixel to the closest color
                        closest_color_num = find_closest_color((r, g, b), color_key)
                        Frame1Array[(x, y)] = closest_color_num
                        first_frame_pixels[(x, y)] = closest_color_num  # Store for looping comparison

                        # Scale the coordinates
                        scaled_x = round(x * 0.1, 1)
                        scaled_y = round(y * 0.1, 1)

                        # Write to stamp.txt
                        stamp_file.write(f"{scaled_x},{scaled_y},{closest_color_num}\n")

        # Process subsequent frames
        header_frame_number = 1  # Start header numbering from 1

        for frame_number in range(2, total_frames + 1):  # Start from frame 2
            frame_path = os.path.join(script_directory, 'Frames', f'frame_{frame_number}.png')
            if not os.path.exists(frame_path):
                if message_callback:
                    message_callback(f"Frame {frame_number} not found at {frame_path}")
                continue

            with Image.open(frame_path) as frame:
                pixels = frame.load()
                current_frame_pixels = {}

                # Collect pixels in current frame
                for y in range(height):
                    for x in range(width):
                        pixel = pixels[x, y]
                        if len(pixel) == 4:
                            r, g, b, a = pixel
                            if a <= 191:
                                current_color_num = -1  # Treat as transparent
                            else:
                                current_color_num = find_closest_color((r, g, b), color_key)
                        else:
                            r, g, b = pixel
                            a = 255  # Assume fully opaque
                            if a <= 191:
                                current_color_num = -1  # Treat as transparent
                            else:
                                current_color_num = find_closest_color((r, g, b), color_key)

                        current_frame_pixels[(x, y)] = current_color_num

                # Compare with Frame1Array and find differences
                diffs = []
                all_positions = set(Frame1Array.keys()) | set(current_frame_pixels.keys())
                for (x, y) in all_positions:
                    prev_color_num = Frame1Array.get((x, y), -1)
                    current_color_num = current_frame_pixels.get((x, y), -1)

                    if current_color_num != prev_color_num:
                        if current_color_num == -1:
                            # Pixel became transparent
                            diffs.append((x, y, -1))
                        else:
                            # Pixel changed color or became visible
                            diffs.append((x, y, current_color_num))

                # Write header and diffs to frames.txt
                with open(frames_txt_path, 'a') as frames_file:
                    # Include delay if variable delays
                    if uniform_delay == -1:
                        frame_delay = delays[frame_number - 1]
                        frames_file.write(f"frame,{header_frame_number},{frame_delay}\n")
                    else:
                        frames_file.write(f"frame,{header_frame_number}\n")
                    for x, y, color_num in diffs:
                        # Scale coordinates by multiplying by 0.1
                        scaled_x = round(x * 0.1, 1)
                        scaled_y = round(y * 0.1, 1)
                        frames_file.write(f"{scaled_x},{scaled_y},{color_num}\n")

                # Update Frame1Array
                Frame1Array = current_frame_pixels.copy()

            if progress_callback:
                progress = (frame_number - 1) / total_frames * 100
                progress_callback(progress)

            header_frame_number += 1  # Increment header frame number

        # After processing all frames, compare last frame to first frame to complete the loop
        # Compare Frame1Array (last frame) with first_frame_pixels (first frame)
        diffs = []
        all_positions = set(first_frame_pixels.keys()) | set(Frame1Array.keys())

        for (x, y) in all_positions:
            first_color_num = first_frame_pixels.get((x, y), -1)
            last_color_num = Frame1Array.get((x, y), -1)

            if first_color_num != last_color_num:
                if first_color_num == -1:
                    # Pixel became visible in first frame
                    diffs.append((x, y, first_color_num))
                elif last_color_num == -1:
                    # Pixel became transparent
                    diffs.append((x, y, -1))
                else:
                    # Pixel changed color
                    diffs.append((x, y, first_color_num))

        # Write header and diffs to frames.txt
        with open(frames_txt_path, 'a') as frames_file:
            # Include delay if variable delays
            final_frame_number = header_frame_number
            if uniform_delay == -1:
                frame_delay = delays[0]  # Use the delay of the first frame
                frames_file.write(f"frame,{final_frame_number},{frame_delay}\n")
            else:
                frames_file.write(f"frame,{final_frame_number}\n")
            for x, y, color_num in diffs:
                # Scale coordinates by multiplying by 0.1
                scaled_x = round(x * 0.1, 1)
                scaled_y = round(y * 0.1, 1)
                frames_file.write(f"{scaled_x},{scaled_y},{color_num}\n")

        if message_callback:
            message_callback(f"Processing of animated image frames complete! Data saved to: {frames_txt_path}")


        # Generate preview GIF after all processing is done
        create_preview_gif(total_frames, delays, preview_folder, progress_callback, message_callback, error_callback)

        img.close()  # Close the image after processing

    except Exception as e:
        if error_callback:
            error_callback(f"An error occurred in process_and_save_gif: {e}")

def save_frames(img, target_size, process_mode, process_params, preprocess_flag, color_key_array,
                progress_callback=None, message_callback=None, error_callback=None):
    """
    Saves each frame of the animated image to the 'Frames' directory after preprocessing, resizing, and applying the selected processing method.
    """
    try:
        # Create a directory to store the frames
        script_directory = os.path.dirname(os.path.abspath(__file__))
        output_folder = os.path.join(script_directory, "Frames")
        os.makedirs(output_folder, exist_ok=True)

        # Delete the contents of the 'Frames' folder before starting
        for filename in os.listdir(output_folder):
            file_path = os.path.join(output_folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
            except Exception as e:
                if message_callback:
                    message_callback(f'Failed to delete {file_path}. Reason: {e}')

        total_frames = img.n_frames
        if message_callback:
            message_callback(f"Processing and saving {total_frames} frames...")

        # Construct color_key from color_key_array
        color_key = {}
        for item in color_key_array:
            color_num = item['number']
            hex_code = item['hex'].lstrip('#')
            rgb = tuple(int(hex_code[i:i + 2], 16) for i in (0, 2, 4))
            color_key[color_num] = rgb

        for frame_number in range(1, total_frames + 1):  # Start frame numbering from 1
            img.seek(frame_number - 1)
            frame = img.copy()

            # Prepare the image (convert to RGBA if needed)
            frame = prepare_image(frame)

            # Resize the image if needed
            if target_size is not None:
                frame = resize_image(frame, target_size)

            # Preprocess the image if needed
            if preprocess_flag:
                frame_np = np.array(frame)
                frame_np = preprocess_image(frame_np, color_key_array)
                frame = Image.fromarray(frame_np, 'RGBA')

            # Apply the processing method to the frame
            frame = process_image(frame, color_key, process_mode, process_params)

            # Save the frame
            frame_file = os.path.join(output_folder, f"frame_{frame_number}.png")
            frame.save(frame_file, "PNG")

            if progress_callback:
                progress = frame_number / total_frames * 100
                progress_callback(progress)

        if message_callback:
            message_callback(f"All frames processed and saved to '{output_folder}'.")

    except Exception as e:
        if error_callback:
            error_callback(f"An error occurred while saving frames: {e}")



def create_preview_gif(total_frames, delays, preview_folder, progress_callback=None, message_callback=None, error_callback=None):
    """
    Creates a new GIF using the frames in the 'Frames' directory and the delay data,
    then saves it as 'preview.gif' in the 'preview' folder.
    """
    try:
        script_directory = os.path.dirname(os.path.abspath(__file__))
        frames_folder = os.path.join(script_directory, "Frames")
        output_gif_path = os.path.join(preview_folder, 'preview.gif')

        frames = []
        frame_durations = []
        for frame_number in range(1, total_frames + 1):
            frame_path = os.path.join(frames_folder, f"frame_{frame_number}.png")
            if not os.path.exists(frame_path):
                if message_callback:
                    message_callback(f"Frame {frame_number} not found at {frame_path}")
                continue
            frame = Image.open(frame_path).convert('RGBA')
            frames.append(frame)
            frame_durations.append(delays[frame_number - 1])  # Duration in ms

        if not frames:
            if error_callback:
                error_callback("No frames found to create preview GIF.")
            return

        # Prepare frames for GIF with transparency
        converted_frames = []
        for frame in frames:
            # Ensure the frame has an alpha channel
            frame = frame.convert('RGBA')

            # Create a transparent background
            background = Image.new('RGBA', frame.size, (0, 0, 0, 0))  # Transparent background

            # Composite the frame onto the background
            combined = Image.alpha_composite(background, frame)

            # Convert to 'P' mode (palette) with an adaptive palette
            # The 'transparency' parameter will handle the transparent color
            combined_p = combined.convert('P', palette=Image.ADAPTIVE, colors=255)

            # Find the color index that should be transparent
            # Here, we assume that the first color in the palette is transparent
            # Alternatively, you can search for a specific color
            # For robustness, let's search for the color with alpha=0
            transparent_color = None
            for idx, color in enumerate(combined_p.getpalette()[::3]):
                r = combined_p.getpalette()[idx * 3]
                g = combined_p.getpalette()[idx * 3 + 1]
                b = combined_p.getpalette()[idx * 3 + 2]
                # Check if this color is used for transparency in the original image
                # This is a simplistic check; for complex images, more logic may be needed
                if (r, g, b) == (0, 0, 0):  # Assuming black is the transparent color
                    transparent_color = idx
                    break

            if transparent_color is None:
                # If not found, append black to the palette and set it as transparent
                combined_p.putpalette(combined_p.getpalette() + [0, 0, 0])
                transparent_color = len(combined_p.getpalette()) // 3 - 1

            # Assign the transparency index
            combined_p.info['transparency'] = transparent_color

            converted_frames.append(combined_p)

        # Save the frames as a GIF with transparency
        converted_frames[0].save(
            output_gif_path,
            save_all=True,
            append_images=converted_frames[1:],
            duration=frame_durations,
            loop=0,
            transparency=converted_frames[0].info['transparency'],
            disposal=2
        )

        if message_callback:
            message_callback(f"Preview GIF saved at: {output_gif_path}")

    except Exception as e:
        if error_callback:
            error_callback(f"An error occurred in create_preview_gif: {e}")

def demo_mode(img, target_size, color_key_array, preprocess_flag, view_mode_strength, progress_callback=None, message_callback=None, error_callback=None):
    """
    Processes the image with all methods and saves outputs in the 'preview' folder.
    Also saves a 'preview.png' of the default processing mode.
    """
    try:
        # Create 'preview' folder
        script_directory = os.path.dirname(os.path.abspath(__file__))
        preview_folder = os.path.join(script_directory, "preview")
        os.makedirs(preview_folder, exist_ok=True)

        # Clear 'preview' folder
        for filename in os.listdir(preview_folder):
            file_path = os.path.join(preview_folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
            except Exception as e:
                if message_callback:
                    message_callback(f'Failed to delete {file_path}. Reason: {e}')

        # Prepare and resize image
        img = prepare_image(img)
        if target_size is not None:
            img = resize_image(img, target_size)

        # Preprocess the image if needed
        if preprocess_flag:
            img_np = np.array(img)
            img_np = preprocess_image(img_np, color_key_array)
            img = Image.fromarray(img_np, 'RGBA')

        # Construct color_key from color_key_array
        color_key = {}
        for item in color_key_array:
            color_num = item['number']
            hex_code = item['hex'].lstrip('#')
            rgb = tuple(int(hex_code[i:i+2], 16) for i in (0, 2, 4))
            color_key[color_num] = rgb

        # List of processing methods to preview
        processing_methods = list(processing_method_registry.keys())

        total_methods = len(processing_methods)
        for idx, method_name in enumerate(processing_methods):
            if message_callback:
                message_callback(f"Processing with {method_name}...")
            process_params = {'strength': view_mode_strength / 100.0}  # Convert to 0.0 - 1.0
            processing_function = processing_method_registry[method_name]
            processed_img = img.copy()
            processed_img = processing_function(processed_img, color_key, process_params)

            # Save processed image to preview folder
            output_file_path = os.path.join(preview_folder, f"{method_name}.png")
            processed_img.save(output_file_path, 'PNG')

            # Save 'preview.png' as the first method's output (e.g., 'floyd_steinberg')
            if idx == 0:
                preview_path = os.path.join(preview_folder, 'preview.png')
                processed_img.save(preview_path)
                if message_callback:
                    message_callback(f"Preview saved at: {preview_path}")

            if progress_callback:
                progress = (idx + 1) / total_methods * 100
                progress_callback(progress)

        if message_callback:
            message_callback("Demo mode processing complete.")

    except Exception as e:
        if error_callback:
            error_callback(f"An error occurred in demo_mode: {e}")

def create_and_clear_preview_folder(message_callback=None):
    """
    Creates and clears the 'preview' folder.
    Returns the path to the 'preview' folder.
    """
    script_directory = os.path.dirname(os.path.abspath(__file__))
    preview_folder = os.path.join(script_directory, "preview")
    os.makedirs(preview_folder, exist_ok=True)

    # Clear 'preview' folder
    for filename in os.listdir(preview_folder):
        file_path = os.path.join(preview_folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
        except Exception as e:
            if message_callback:
                message_callback(f'Failed to delete {file_path}. Reason: {e}')
    return preview_folder

def main(view_mode, image_path, preprocess_flag, resize_dim, color_key_array, process_mode, process_params, progress_callback=None, message_callback=None, error_callback=None):
    """
    Main function to process the image or GIF based on the provided parameters.
    Added support for progress and error reporting via callbacks.
    """
    try:
        if message_callback:
            message_callback("Initializing...")

        # Handle 'clip' as image_path
        if image_path == 'clip':
            try:
                img = ImageGrab.grabclipboard()
                if img is None:
                    if error_callback:
                        error_callback("No image found in clipboard.")
                    return
                elif isinstance(img, list):
                    # Clipboard contains file paths
                    image_files = [f for f in img if os.path.isfile(f)]
                    if not image_files:
                        if error_callback:
                            error_callback("No image files found in clipboard.")
                        return
                    # Use the first image file
                    image_path = image_files[0]
                    img = Image.open(image_path)
                    if message_callback:
                        message_callback(f"Image loaded from clipboard file: {image_path}")
                elif isinstance(img, Image.Image):
                    if message_callback:
                        message_callback("Image grabbed from clipboard.")
                else:
                    if error_callback:
                        error_callback("Clipboard does not contain an image or image file.")
                    return
            except ImportError:
                if error_callback:
                    error_callback("PIL.ImageGrab is not available on this system.")
                return
            except Exception as e:
                if error_callback:
                    error_callback(f"Error accessing clipboard: {e}")
                return
        else:
            try:
                img = Image.open(image_path)
            except FileNotFoundError:
                if error_callback:
                    error_callback(f"File not found: {image_path}")
                return
            except UnidentifiedImageError:
                if error_callback:
                    error_callback(f"The file '{image_path}' is not a valid image.")
                return

        # Check if image is animated
        is_multiframe = getattr(img, "is_animated", False)

        # Enter demo mode if view_mode is between 0 and 100
        if 0 <= view_mode <= 100:
            if message_callback:
                message_callback(f"Entering demo mode with strength {view_mode}...")
            demo_mode(img, resize_dim, color_key_array, preprocess_flag, view_mode, progress_callback, message_callback, error_callback)

        else:
            # Process single image or animated image
            if is_multiframe:
                if message_callback:
                    message_callback("Processing animated image...")
                # Save the image to a temporary path if it's from the clipboard
                if image_path == 'clip':
                    temp_image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'clipboard_image.webp')
                    img.save(temp_image_path, 'WEBP')
                    image_path = temp_image_path
                process_and_save_gif(image_path, resize_dim, process_mode, process_params, color_key_array, preprocess_flag, progress_callback, message_callback, error_callback)
            else:
                if message_callback:
                    message_callback("Processing image...")
                process_and_save_image(img, resize_dim, process_mode, process_params, color_key_array, preprocess_flag, progress_callback, message_callback, error_callback)

        if message_callback:
            message_callback("Processing complete!")

    except Exception as e:
        if error_callback:
            error_callback(str(e))