import sys
import os
import shutil
import threading
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFileDialog, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QCheckBox, QSlider, QComboBox,
    QProgressBar, QMessageBox, QStackedWidget, QLineEdit, QSizePolicy,
    QFormLayout, QGroupBox, QColorDialog, QInputDialog, QScrollArea, QGridLayout,
    QSpacerItem
)
from PySide6.QtGui import QPixmap, QImage, QColor, QMovie, QIcon, QFont
from PySide6.QtCore import Qt, Signal, QObject, QTimer, QSize

# Dynamically import imagepawcess.py
script_directory = os.path.dirname(os.path.abspath(__file__))
current_stamp_data_path = os.path.join(script_directory, 'Current_Stamp_Data')
sys.path.append(current_stamp_data_path)
try:
    import imagepawcess
except ImportError as e:
    print("Failed to import imagepawcess.py:", e)
    sys.exit(1)


class WorkerSignals(QObject):
    progress = Signal(float)  # For progress percentage
    message = Signal(str)     # For status messages
    error = Signal(str)


class ImageProcessingThread(threading.Thread):
    def __init__(self, params, signals):
        super().__init__()
        self.params = params
        self.signals = signals

    def run(self):
        try:
            imagepawcess.main(
                view_mode=self.params['view_mode'],
                image_path=self.params['image_path'],
                preprocess_flag=self.params['preprocess_flag'],
                resize_dim=self.params['resize_dim'],
                color_key_array=self.params['color_key_array'],
                process_mode=self.params['process_mode'],
                process_params=self.params['process_params'],
                progress_callback=self.signals.progress.emit,
                message_callback=self.signals.message.emit,
                error_callback=self.signals.error.emit
            )
        except Exception as e:
            self.signals.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Image Processing GUI")
        self.setMinimumSize(800, 800)  # Ensures the window is at least 800px in y-axis
        self.move_to_center()

        # Initialize variables
        self.image_path = None
        self.image = None
        self.is_gif = False
        self.current_image_pixmap = None
        self.parameter_widgets = {}
        self.new_color = None  # Single color 5
        self.default_color_key_array = [
            {'number': 0, 'hex': 'ffe7c5', 'boost': 1.2, 'threshold': 20},
            {'number': 1, 'hex': '2a3844', 'boost': 1.2, 'threshold': 20},
            {'number': 2, 'hex': 'd70b5d', 'boost': 1.2, 'threshold': 20},
            {'number': 3, 'hex': '0db39e', 'boost': 1.2, 'threshold': 20},
            {'number': 4, 'hex': 'f4c009', 'boost': 1.2, 'threshold': 20},
            {'number': 6, 'hex': 'bac357', 'boost': 1.2, 'threshold': 20},
        ]

        # Setup UI
        self.setup_ui()

    def move_to_center(self):
        """
        Moves the window to the center of the screen.
        """
        screen = QApplication.primaryScreen()
        screen_geometry = screen.geometry()
        x = (screen_geometry.width() - self.width()) // 2
        y = (screen_geometry.height() - self.height()) // 2
        self.move(x, y)

    def setup_ui(self):
        # Apply dark-themed stylesheet with purple accents and Comic Sans font
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2e2e2e;
                color: #ffffff;
                font-family: 'Comic Sans MS';
            }
            QPushButton {
                background-color: #7b1fa2;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #9c27b0;
            }
            QPushButton:disabled {
                background-color: #4a148c;
            }
            QLabel {
                font-size: 14px;
                color: #ffffff;
            }
            QCheckBox {
                font-size: 14px;
                color: #ffffff;
            }
            QSlider::groove:horizontal {
                height: 8px;
                background: #7b1fa2;
                border-radius: 4px;
            }
            QSlider::handle:horizontal {
                background: #ba68c8;
                border: 1px solid #ffffff;
                width: 18px;
                margin: -5px 0;
                border-radius: 9px;
            }
            QComboBox, QSpinBox, QLineEdit {
                font-size: 14px;
                padding: 5px;
                border: 1px solid #7b1fa2;
                border-radius: 5px;
                background-color: #424242;
                color: #ffffff;
            }
            QProgressBar {
                height: 15px;
                border: 1px solid #7b1fa2;
                border-radius: 7px;
                text-align: center;
                background-color: #424242;
            }
            QProgressBar::chunk {
                background-color: #ba68c8;
                width: 1px;
            }
            QGroupBox {
                border: 1px solid #7b1fa2;
                border-radius: 5px;
                margin-top: 10px;
                color: #ffffff;
            }
        """)

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main layout
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)

        # Stacked widget to switch between menus
        self.stacked_widget = QStackedWidget()
        main_layout.addWidget(self.stacked_widget)

        # Initial menu
        self.setup_initial_menu()
        # Secondary menu
        self.setup_secondary_menu()
        # Result menu
        self.setup_result_menu()
        # Load Save menu will be dynamically created

        # Status label (placed above the progress bar)
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(self.status_label)

        # Progress bar (only visible in secondary menu)
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumHeight(15)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)  # Hidden by default
        main_layout.addWidget(self.progress_bar)

    def setup_initial_menu(self):
        # Initial widget
        initial_widget = QWidget()
        initial_layout = QVBoxLayout()
        initial_layout.setAlignment(Qt.AlignCenter)
        initial_widget.setLayout(initial_layout)

        # Image selection buttons
        image_selection_layout = QHBoxLayout()
        image_selection_layout.setSpacing(20)
        image_selection_layout.setAlignment(Qt.AlignCenter)
        initial_layout.addLayout(image_selection_layout)

        # New Image from Files button
        self.new_image_files_button = QPushButton("New Image from Files")
        self.new_image_files_button.clicked.connect(self.open_image_from_files)
        image_selection_layout.addWidget(self.new_image_files_button)

        # New Image from Clipboard button
        self.new_image_clipboard_button = QPushButton("New Image from Clipboard")
        self.new_image_clipboard_button.clicked.connect(self.open_image_from_clipboard)
        image_selection_layout.addWidget(self.new_image_clipboard_button)

        # Save and Load buttons
        save_load_layout = QHBoxLayout()
        save_load_layout.setSpacing(20)
        save_load_layout.setAlignment(Qt.AlignCenter)
        initial_layout.addLayout(save_load_layout)

        self.save_current_button = QPushButton("Save Current")
        self.save_current_button.clicked.connect(self.save_current)
        save_load_layout.addWidget(self.save_current_button)

        self.load_save_button = QPushButton("Load Save")
        self.load_save_button.clicked.connect(self.load_save)
        save_load_layout.addWidget(self.load_save_button)

        # Hide Save and Load buttons as they are unfinished
        self.save_current_button.setVisible(False)
        self.load_save_button.setVisible(False)

        # Add initial widget to stacked widget
        self.stacked_widget.addWidget(initial_widget)

    def setup_secondary_menu(self):
        # Secondary widget
        secondary_widget = QWidget()
        secondary_layout = QVBoxLayout()
        secondary_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        secondary_widget.setLayout(secondary_layout)
        secondary_widget.setMinimumHeight(800)  # Ensures the menu is at least 800px in y-axis

        # Image display label
        self.image_label = QLabel("No image selected")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.image_label.setScaledContents(True)  # Modified to allow scaling
        secondary_layout.addWidget(self.image_label)

        # Spacer
        secondary_layout.addSpacerItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Resize and processing options
        self.setup_options_ui(secondary_layout)

        # Add secondary widget to stacked widget
        self.stacked_widget.addWidget(secondary_widget)

    def setup_result_menu(self):
        # Result widget
        result_widget = QWidget()
        result_layout = QVBoxLayout()
        result_layout.setAlignment(Qt.AlignCenter)
        result_widget.setLayout(result_layout)

        # Processed image display label
        self.result_image_label = QLabel()
        self.result_image_label.setAlignment(Qt.AlignCenter)
        self.result_image_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.result_image_label.setScaledContents(False)  # Prevent automatic scaling
        result_layout.addWidget(self.result_image_label)

        # Spacer
        result_layout.addSpacerItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Buttons
        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(20)
        buttons_layout.setAlignment(Qt.AlignCenter)
        result_layout.addLayout(buttons_layout)

        self.awrooo_button = QPushButton("Awrooo! (looks good)")
        self.awrooo_button.clicked.connect(self.close_application)
        buttons_layout.addWidget(self.awrooo_button)

        self.maybe_not_button = QPushButton("Maybe not...")
        self.maybe_not_button.clicked.connect(self.retry_processing)
        buttons_layout.addWidget(self.maybe_not_button)

        # Add result widget to stacked widget
        self.stacked_widget.addWidget(result_widget)

    def close_application(self):
        self.close()

    def retry_processing(self):
        self.stacked_widget.setCurrentIndex(1)  # Return to secondary menu
        # Do not reset user selections to allow fine-tuning

    def setup_options_ui(self, layout):
        # Resize options
        resize_layout = QHBoxLayout()
        resize_layout.setSpacing(10)
        layout.addLayout(resize_layout)

        resize_label = QLabel("Resize (max dimension):")
        resize_layout.addWidget(resize_label)

        self.resize_slider = QSlider(Qt.Horizontal)
        self.resize_slider.setRange(1, 400)
        self.resize_slider.setValue(200)
        self.resize_slider.setTickInterval(10)
        self.resize_slider.setTickPosition(QSlider.TicksBelow)
        resize_layout.addWidget(self.resize_slider)

        self.resize_value_label = QLabel("200")
        resize_layout.addWidget(self.resize_value_label)

        self.resize_slider.valueChanged.connect(self.resize_slider_changed)

        # Preprocessing option renamed to "Enhance Image"
        enhance_layout = QHBoxLayout()
        enhance_layout.setSpacing(10)
        layout.addLayout(enhance_layout)

        self.enhance_checkbox = QCheckBox("Enhance Image")
        self.enhance_checkbox.setChecked(True)  # On by default
        enhance_layout.addWidget(self.enhance_checkbox)

        # Processing methods dropdown
        processing_layout = QHBoxLayout()
        processing_layout.setSpacing(10)
        layout.addLayout(processing_layout)

        processing_label = QLabel("Processing Method:")
        processing_layout.addWidget(processing_label)

        # Retrieve processing methods from imagepawcess
        self.processing_methods = list(imagepawcess.processing_method_registry.keys())
        self.processing_combobox = QComboBox()
        self.processing_combobox.addItems(self.processing_methods)
        processing_layout.addWidget(self.processing_combobox)

        # Create method_options_layout before connecting the signal
        self.method_options_layout = QFormLayout()
        layout.addLayout(self.method_options_layout)

        # Set default processing method to "stucki"
        if "stucki" in self.processing_methods:
            index = self.processing_combobox.findText("stucki")
            if index != -1:
                self.processing_combobox.setCurrentIndex(index)
        else:
            # If "stucki" is not available, set to the first method
            self.processing_combobox.setCurrentIndex(0)

        # Connect the signal after setting up method_options_layout
        self.processing_combobox.currentTextChanged.connect(self.processing_method_changed)

        # Initialize parameter widgets
        self.parameter_widgets = {}

        # Process Button
        self.process_button = QPushButton("Process Image")
        self.process_button.clicked.connect(self.process_image)
        layout.addWidget(self.process_button)

        # Spacer
        layout.addSpacerItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Color options
        self.setup_color_options_ui(layout)

        # Initially populate method options
        self.processing_method_changed(self.processing_combobox.currentText())

    def resize_slider_changed(self, value):
        self.resize_value_label.setText(str(value))

    def setup_color_options_ui(self, layout):
        # Color selection options
        color_options_group = QGroupBox()
        color_options_group.setTitle("")  # Remove "Color Options" text
        self.color_options_layout = QVBoxLayout()
        color_options_group.setLayout(self.color_options_layout)
        layout.addWidget(color_options_group)

        # Color checkboxes with color box to the left of the checkbox
        self.color_checkboxes = {}
        for color in self.default_color_key_array:
            color_number = color['number']
            color_hex = color['hex']

            # Create a horizontal layout for color box and checkbox
            color_layout = QHBoxLayout()
            color_layout.setSpacing(10)

            # Color box label
            color_label = QLabel()
            color_label.setFixedSize(20, 20)
            color_label.setStyleSheet(f"background-color: #{color_hex}; border: 1px solid #ffffff;")
            color_layout.addWidget(color_label)

            checkbox = QCheckBox(f"Color {color_number}")
            checkbox.setChecked(True)  # Default to checked
            color_layout.addWidget(checkbox)

            # Add the layout to the color options layout
            self.color_options_layout.addLayout(color_layout)
            self.color_checkboxes[color_number] = checkbox

        # Replacement color selection within color options
        self.replacement_color_layout = QHBoxLayout()
        self.color_options_layout.addLayout(self.replacement_color_layout)

        replacement_label = QLabel("Replace a chalk color number with RGB:")
        self.replacement_color_combobox = QComboBox()

        # Add colors to combobox with color-coded items
        for color in self.default_color_key_array:
            color_number = color['number']
            color_hex = color['hex']
            pixmap = QPixmap(20, 20)
            pixmap.fill(QColor(f"#{color_hex}"))
            icon = QIcon(pixmap)
            self.replacement_color_combobox.addItem(icon, f"Color {color_number}", userData=color_number)

        self.replacement_color_combobox.setCurrentIndex(-1)  # No selection by default
        self.replacement_color_layout.addWidget(replacement_label)
        self.replacement_color_layout.addWidget(self.replacement_color_combobox)

        # New color addition
        self.add_new_color_button = QPushButton("New color for rgb")
        self.add_new_color_button.clicked.connect(self.add_new_color)
        self.color_options_layout.addWidget(self.add_new_color_button)

    def add_new_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            color_hex = color.name()[1:]  # Remove '#' from '#RRGGBB'

            # Check if a new color under number 5 already exists
            if self.new_color:
                # Remove existing color 5 from UI
                existing_color_layout = None
                for i in range(self.color_options_layout.count()):
                    item = self.color_options_layout.itemAt(i)
                    if item and item.layout() and isinstance(item.layout(), QHBoxLayout):
                        checkbox = item.layout().itemAt(1).widget()
                        if isinstance(checkbox, QCheckBox) and checkbox.text() == "Color 5":
                            existing_color_layout = item.layout()
                            break
                if existing_color_layout:
                    widget = existing_color_layout.itemAt(0).widget()
                    if widget:
                        existing_color_layout.removeWidget(widget)
                        widget.deleteLater()
                    checkbox = existing_color_layout.itemAt(1).widget()
                    if checkbox:
                        existing_color_layout.removeWidget(checkbox)
                        checkbox.deleteLater()

                # Remove existing color 5 from replacement combobox
                index_to_remove = -1
                for index in range(self.replacement_color_combobox.count()):
                    if self.replacement_color_combobox.itemData(index) == 5:
                        index_to_remove = index
                        break
                if index_to_remove != -1:
                    self.replacement_color_combobox.removeItem(index_to_remove)

            # Assign number 5 to the new color
            new_color = {'number': 5, 'hex': color_hex, 'boost': 1.2, 'threshold': 20}
            self.new_color = new_color

            # Create a horizontal layout for the new color
            color_layout = QHBoxLayout()
            color_layout.setSpacing(10)

            # Color box label
            color_label = QLabel()
            color_label.setFixedSize(20, 20)
            color_label.setStyleSheet(f"background-color: #{color_hex}; border: 1px solid #ffffff;")
            color_layout.addWidget(color_label)

            # Checkbox for the new color
            checkbox = QCheckBox("Color 5")
            checkbox.setChecked(True)  # Default to checked
            color_layout.addWidget(checkbox)

            # Add the new color layout to the color options
            self.color_options_layout.addLayout(color_layout)
            self.color_checkboxes[new_color['number']] = checkbox

            # Add the new color to the replacement combobox
            pixmap = QPixmap(20, 20)
            pixmap.fill(QColor(f"#{color_hex}"))
            icon = QIcon(pixmap)
            self.replacement_color_combobox.addItem(icon, f"Color 5", userData=5)

            QMessageBox.information(self, "Color Added", f"New color #{color_hex} added as number 5.")
        else:
            QMessageBox.warning(self, "No Color Selected", "No color was selected.")

    def open_image_from_files(self):
        # Open file dialog
        file_dialog = QFileDialog(self)
        file_dialog.setNameFilters(["Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp)"])
        if file_dialog.exec():
            file_path = file_dialog.selectedFiles()[0]
            self.image_path = file_path
            self.load_image(file_path)
            self.stacked_widget.setCurrentIndex(1)  # Switch to secondary menu

    def open_image_from_clipboard(self):
        # Load image from clipboard
        clipboard = QApplication.clipboard()
        mime_data = clipboard.mimeData()
        if mime_data.hasImage():
            image = clipboard.image()
            self.current_image_pixmap = QPixmap.fromImage(image)
            self.image_label.setPixmap(self.current_image_pixmap)
            self.image_label.setScaledContents(True)  # Modified to allow scaling
            self.image_path = 'clip'
            self.image = image
            self.is_gif = False
            self.stacked_widget.setCurrentIndex(1)  # Switch to secondary menu
        else:
            QMessageBox.warning(self, "Error", "No image found in clipboard.")

    def load_image(self, file_path):
        image = QImage(file_path)
        if image.isNull():
            QMessageBox.warning(self, "Error", "Failed to load image.")
            return
        self.current_image_pixmap = QPixmap.fromImage(image)
        self.image_label.setPixmap(self.current_image_pixmap)
        self.image_label.setScaledContents(True)  # Modified to allow scaling
        self.image = image

        # Check if the image is a GIF
        self.is_gif = file_path.lower().endswith('.gif')
        if self.is_gif and self.resize_slider.value() > 200:
            QMessageBox.warning(self, "Warning", "High-resolution GIFs may cause lag in-game.")

        # Adjust resize_slider default value
        width = image.width()
        height = image.height()
        max_dimension = max(width, height)
        if max_dimension <= 400:
            self.resize_slider.setValue(max_dimension)
        else:
            self.resize_slider.setValue(200)

    def processing_method_changed(self, method_name):
        # Clear existing parameter widgets
        for i in reversed(range(self.method_options_layout.count())):
            widget = self.method_options_layout.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()
        self.parameter_widgets.clear()

        # Retrieve the processing function
        processing_function = imagepawcess.processing_method_registry.get(method_name)
        if not processing_function:
            return

        # Retrieve default parameters
        default_params = getattr(processing_function, 'default_params', {})

        # Dynamically create input widgets for parameters
        for param_name, default_value in default_params.items():
            label = QLabel(f"{param_name.capitalize()}:")
            if isinstance(default_value, float) or isinstance(default_value, int):
                if isinstance(default_value, float):
                    slider = QSlider(Qt.Horizontal)
                    slider.setRange(0, 100)
                    slider.setValue(int(default_value * 100))
                    slider.setTickInterval(10)
                    slider.setTickPosition(QSlider.TicksBelow)
                    slider.valueChanged.connect(self.parameter_value_changed)
                    self.method_options_layout.addRow(label, slider)
                    self.parameter_widgets[param_name] = slider
                else:
                    slider = QSlider(Qt.Horizontal)
                    slider.setRange(1, 400)
                    slider.setValue(default_value)
                    slider.setTickInterval(10)
                    slider.setTickPosition(QSlider.TicksBelow)
                    self.method_options_layout.addRow(label, slider)
                    self.parameter_widgets[param_name] = slider
            elif isinstance(default_value, bool):
                # Use a checkbox for boolean values
                checkbox = QCheckBox()
                checkbox.setChecked(default_value)
                self.method_options_layout.addRow(label, checkbox)
                self.parameter_widgets[param_name] = checkbox
            elif isinstance(default_value, str):
                if param_name in ['line_color', 'line_style']:
                    # Use a combo box for predefined options
                    combo_box = QComboBox()
                    if param_name == 'line_color':
                        combo_box.addItems(['auto', 'black', 'white'])
                    elif param_name == 'line_style':
                        combo_box.addItems(['black_on_white', 'white_on_black'])
                    combo_box.setCurrentText(default_value)
                    self.method_options_layout.addRow(label, combo_box)
                    self.parameter_widgets[param_name] = combo_box
                else:
                    line_edit = QLineEdit(default_value)
                    self.method_options_layout.addRow(label, line_edit)
                    self.parameter_widgets[param_name] = line_edit
            else:
                line_edit = QLineEdit(str(default_value))
                self.method_options_layout.addRow(label, line_edit)
                self.parameter_widgets[param_name] = line_edit

    def parameter_value_changed(self, value):
        # Update any dependent UI elements if necessary
        pass

    def process_image(self):
        if not self.image_path:
            QMessageBox.warning(self, "Error", "No image selected.")
            return

        # Collect parameters
        view_mode = -1  # Default view mode

        enhance_flag = self.enhance_checkbox.isChecked()  # From "Enhance Image" checkbox

        resize_dim = self.resize_slider.value()

        # Build color_key_array based on user selections
        color_key_array = []

        # Collect selected default colors
        for color in self.default_color_key_array:
            color_number = color['number']
            checkbox = self.color_checkboxes[color_number]
            if checkbox.isChecked():
                color_key_array.append(color.copy())

        # Collect selected new color (number 5)
        if self.new_color:
            checkbox = self.color_checkboxes.get(5)
            if checkbox and checkbox.isChecked():
                color_key_array.append(self.new_color.copy())

        # Handle replacement of color number with 5
        selected_index = self.replacement_color_combobox.currentIndex()
        if selected_index != -1:
            # Get the selected color number to replace with 5
            replacement_color_number = self.replacement_color_combobox.currentData()
            # Find the color in color_key_array and change its number to 5
            for color in color_key_array:
                if color['number'] == replacement_color_number:
                    color['number'] = 5
                    break

        process_mode = self.processing_combobox.currentText()

        # Collect parameters from parameter widgets
        process_params = {}
        processing_function = imagepawcess.processing_method_registry.get(process_mode)
        if not processing_function:
            QMessageBox.warning(self, "Error", "Invalid processing method selected.")
            return
        default_params = getattr(processing_function, 'default_params', {})
        for param_name, default_value in default_params.items():
            widget = self.parameter_widgets.get(param_name)
            if isinstance(widget, QSlider):
                if isinstance(default_value, float):
                    value = widget.value() / 100.0
                else:
                    value = widget.value()
                process_params[param_name] = value
            elif isinstance(widget, QCheckBox):
                process_params[param_name] = widget.isChecked()
            elif isinstance(widget, QComboBox):
                process_params[param_name] = widget.currentText()
            elif isinstance(widget, QLineEdit):
                text = widget.text()
                if isinstance(default_value, int):
                    try:
                        process_params[param_name] = int(text)
                    except ValueError:
                        process_params[param_name] = default_value
                elif isinstance(default_value, float):
                    try:
                        process_params[param_name] = float(text)
                    except ValueError:
                        process_params[param_name] = default_value
                else:
                    process_params[param_name] = text
            else:
                process_params[param_name] = default_value

        # Prepare parameters for image processing
        params = {
            'view_mode': view_mode,
            'image_path': self.image_path,
            'preprocess_flag': enhance_flag,
            'resize_dim': resize_dim,
            'color_key_array': color_key_array,
            'process_mode': process_mode,
            'process_params': process_params,
        }

        # Disable the process button to prevent multiple clicks
        self.process_button.setEnabled(False)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)  # Show progress bar in secondary menu
        self.status_label.setText("Starting processing...")

        # Start image processing in a separate thread
        self.signals = WorkerSignals()
        self.signals.progress.connect(self.update_progress)
        self.signals.message.connect(self.update_status)
        self.signals.error.connect(self.show_error)

        self.processing_thread = ImageProcessingThread(params, self.signals)
        self.processing_thread.start()
        self.monitor_thread()

    def monitor_thread(self):
        if self.processing_thread.is_alive():
            QTimer.singleShot(100, self.monitor_thread)
        else:
            self.progress_bar.setValue(100)
            self.status_label.setText("Processing complete!")
            # Load the processed image
            preview_dir = os.path.join(script_directory, 'Current_Stamp_Data', 'preview')
            preview_png_path = os.path.join(preview_dir, 'preview.png')
            preview_gif_path = os.path.join(preview_dir, 'preview.gif')
            if os.path.exists(preview_gif_path):
                # Load and display GIF
                self.result_movie = QMovie(preview_gif_path)
                self.result_image_label.setMovie(self.result_movie)
                self.result_movie.start()
                self.result_image_label.setScaledContents(False)  # Prevent scaling
                self.result_image_label.setAlignment(Qt.AlignCenter)
                self.stacked_widget.setCurrentIndex(2)  # Switch to result menu
            elif os.path.exists(preview_png_path):
                # Load and display PNG
                processed_image = QImage(preview_png_path)
                if processed_image.isNull():
                    QMessageBox.warning(self, "Error", "Failed to load processed image.")
                    self.process_button.setEnabled(True)
                    self.progress_bar.setVisible(False)
                    self.status_label.setText("Error occurred during processing.")
                    return
                pixmap = QPixmap.fromImage(processed_image)
                # Determine scaling to prevent upscaling
                label_size = self.result_image_label.size()
                pixmap_size = pixmap.size()
                if pixmap.width() > label_size.width() or pixmap.height() > label_size.height():
                    pixmap = pixmap.scaled(
                        label_size,
                        Qt.KeepAspectRatio,
                        Qt.FastTransformation  # Ensures hard edges without smoothing
                    )
                self.result_image_label.setPixmap(pixmap)
                self.result_image_label.setScaledContents(False)  # Prevent scaling
                self.result_image_label.setAlignment(Qt.AlignCenter)
                self.stacked_widget.setCurrentIndex(2)  # Switch to result menu
            else:
                QMessageBox.warning(self, "Error", "Processed image not found.")
                self.process_button.setEnabled(True)
                self.progress_bar.setVisible(False)
                self.status_label.setText("Error occurred during processing.")

            # Re-enable the process button and hide progress bar
            self.process_button.setEnabled(True)
            self.progress_bar.setVisible(False)

    def update_progress(self, progress):
        self.progress_bar.setValue(progress)
        QApplication.processEvents()

    def update_status(self, message):
        self.status_label.setText(message)
        QApplication.processEvents()

    def show_error(self, message):
        QMessageBox.warning(self, "Error", message)
        self.process_button.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Error occurred during processing.")

    def save_current(self):
        # Prompt user to type in the name to save the current image as
        save_name, ok = QInputDialog.getText(self, 'Save Current Stamp', 'Enter name to save current stamp:')
        if ok and save_name:
            # Create directory under Saved_Stamp_Data with the given name
            saved_stamp_dir = os.path.join(script_directory, 'Saved_Stamp_Data', save_name)
            os.makedirs(saved_stamp_dir, exist_ok=True)

            # Copy files from Current_Stamp_Data to the new directory
            current_stamp_dir = os.path.join(script_directory, 'Current_Stamp_Data')

            # Copy stamp.txt
            source_stamp = os.path.join(current_stamp_dir, 'stamp.txt')
            dest_stamp = os.path.join(saved_stamp_dir, 'stamp.txt')
            if os.path.exists(source_stamp):
                shutil.copy2(source_stamp, dest_stamp)

            # Copy frames.txt if exists
            source_frames = os.path.join(current_stamp_dir, 'frames.txt')
            dest_frames = os.path.join(saved_stamp_dir, 'frames.txt')
            if os.path.exists(source_frames):
                shutil.copy2(source_frames, dest_frames)

            # Copy preview image (png or gif)
            source_preview_dir = os.path.join(current_stamp_dir, 'preview')
            dest_preview_dir = os.path.join(saved_stamp_dir, 'preview')
            if os.path.exists(dest_preview_dir):
                shutil.rmtree(dest_preview_dir)
            if os.path.exists(source_preview_dir):
                shutil.copytree(source_preview_dir, dest_preview_dir)

            QMessageBox.information(self, "Save Successful", f"Stamp '{save_name}' saved successfully.")
            self.close()  # Close the GUI after saving
        else:
            # User canceled or didn't enter a name
            pass

    def load_save(self):
        # Open a new menu that displays all saved stamps
        self.setup_load_save_menu()
        self.stacked_widget.setCurrentIndex(3)  # Assuming index 3 is the load save menu

    def setup_load_save_menu(self):
        # Load Save widget
        load_save_widget = QWidget()
        load_save_layout = QVBoxLayout()
        load_save_widget.setLayout(load_save_layout)

        # Scroll area to hold the stamps
        scroll_area = QScrollArea()
        scroll_area_widget = QWidget()
        scroll_area_layout = QGridLayout()
        scroll_area_widget.setLayout(scroll_area_layout)
        scroll_area.setWidget(scroll_area_widget)
        scroll_area.setWidgetResizable(True)
        load_save_layout.addWidget(scroll_area)

        # Go Back button
        go_back_button = QPushButton("Go Back")
        go_back_button.clicked.connect(self.go_back_to_initial_menu)
        load_save_layout.addWidget(go_back_button)

        # Load saved stamps from Saved_Stamp_Data
        saved_stamp_dir = os.path.join(script_directory, 'Saved_Stamp_Data')
        if not os.path.exists(saved_stamp_dir):
            os.makedirs(saved_stamp_dir)
        stamp_names = os.listdir(saved_stamp_dir)

        row = 0
        col = 0
        for stamp_name in stamp_names:
            stamp_folder = os.path.join(saved_stamp_dir, stamp_name)
            if not os.path.isdir(stamp_folder):
                continue

            # Get preview image
            preview_dir = os.path.join(stamp_folder, 'preview')
            preview_png = os.path.join(preview_dir, 'preview.png')
            preview_gif = os.path.join(preview_dir, 'preview.gif')
            if os.path.exists(preview_gif):
                # Use GIF
                label = QLabel()
                movie = QMovie(preview_gif)
                label.setMovie(movie)
                movie.start()
                label.setFixedSize(80, 80)  # Modified size for smaller previews
                label.setAlignment(Qt.AlignCenter)
            elif os.path.exists(preview_png):
                # Use PNG
                label = QLabel()
                pixmap = QPixmap(preview_png)
                label.setPixmap(pixmap.scaled(80, 80, Qt.KeepAspectRatio, Qt.FastTransformation))  # Modified size and transformation
                label.setFixedSize(80, 80)  # Modified size for smaller previews
                label.setAlignment(Qt.AlignCenter)
            else:
                # No preview image
                label = QLabel("No Preview")
                label.setAlignment(Qt.AlignCenter)
                label.setFixedSize(80, 80)  # Modified size for smaller previews

            # Create a button to select this stamp
            stamp_button = QPushButton(stamp_name)
            stamp_button.setFixedSize(100, 30)
            stamp_button.clicked.connect(lambda checked, name=stamp_name: self.load_selected_stamp(name))

            # Add to layout
            grid_layout = QVBoxLayout()
            grid_layout.addWidget(label)
            grid_layout.addWidget(stamp_button)

            container_widget = QWidget()
            container_widget.setLayout(grid_layout)

            scroll_area_layout.addWidget(container_widget, row, col)

            col += 1
            if col > 2:
                col = 0
                row += 1

        # Add load_save_widget to stacked_widget
        if self.stacked_widget.count() < 4:
            self.stacked_widget.addWidget(load_save_widget)
        else:
            # Replace existing load_save_widget
            self.stacked_widget.removeWidget(self.stacked_widget.widget(3))
            self.stacked_widget.insertWidget(3, load_save_widget)

    def go_back_to_initial_menu(self):
        self.stacked_widget.setCurrentIndex(0)  # Return to initial menu

    def load_selected_stamp(self, stamp_name):
        # Copy stamp.txt and frames.txt (if any) to Current_Stamp_Data
        saved_stamp_dir = os.path.join(script_directory, 'Saved_Stamp_Data', stamp_name)
        current_stamp_dir = os.path.join(script_directory, 'Current_Stamp_Data')

        # Copy stamp.txt
        source_stamp = os.path.join(saved_stamp_dir, 'stamp.txt')
        dest_stamp = os.path.join(current_stamp_dir, 'stamp.txt')
        if os.path.exists(source_stamp):
            shutil.copy2(source_stamp, dest_stamp)

        # Copy frames.txt if exists
        source_frames = os.path.join(saved_stamp_dir, 'frames.txt')
        dest_frames = os.path.join(current_stamp_dir, 'frames.txt')
        if os.path.exists(source_frames):
            shutil.copy2(source_frames, dest_frames)

        # Copy preview images
        source_preview_dir = os.path.join(saved_stamp_dir, 'preview')
        dest_preview_dir = os.path.join(current_stamp_dir, 'preview')
        if os.path.exists(dest_preview_dir):
            shutil.rmtree(dest_preview_dir)
        if os.path.exists(source_preview_dir):
            shutil.copytree(source_preview_dir, dest_preview_dir)

        QMessageBox.information(self, "Load Successful", f"Stamp '{stamp_name}' loaded successfully.")
        self.close()  # Close the GUI after loading

    def delete_selected_stamp(self, stamp_name):
        # Removed as per request
        pass

    def show_preview_menu(self):
        # Preview menu is removed as per the latest request
        pass

    # Removed setup_preview_menu and related methods as the preview checkbox and slider are removed

    def setup_preview_menu(self):
        pass  # No implementation needed

    def go_back_to_processing_menu(self):
        self.stacked_widget.setCurrentIndex(1)  # Return to processing menu


if __name__ == '__main__':
    # Prevent cmd window from opening (for Windows)
    if sys.platform.startswith('win'):
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(u"ImageProcessingGUI")

    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
