# _Stamp_Mod
little hobby project for webfish - IN BETA!!!!

youll need python!  
https://www.python.org/
get it here rawr

just like, download the zip, put er in ur mods folder, unextract...

https://github.com/unpaid-intern/_Stamp_Mod/blob/main/PurplePuppy.Stamps.zip

once its there and python is installed on ur machine: 

initialize using "NyooooomLetsGo.py" 

!! WARNING !! 
will not work as intended if you launch through HOOK LINE SINKER

just give it a good click it should do somethin

--- Instructions for Use In-Game ---


backspace && = keys: will open the gui to upload or pick a different image *IMPORTANT*

= key: spawn in an image where the cursor is (MAX OF ONE)

= key: will play a gif if the image is a gif and is placed down

backspace && - keys:  will change gif playback mode.

- key: get rid of all images spawned in.

shift && = keys: will put the image at the player

ctrl && = keys: will put the image in the water if ur in the dock

