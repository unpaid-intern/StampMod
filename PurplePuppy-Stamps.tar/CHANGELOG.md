# 0.1.0
epic troll!! (didn't work)
# 0.1.1
Still didn't work!
# 0.1.2
AAAAAAUGH im STUPID
# 1.0.0
finally got it to link to correct executable directory after stealing script from KMod shoutout KMod
# 1.0.1
general bugfixes
# 1.0.2
got ctrl z to function and changed keybinds
# 2.0.0
> we r getting out of beta with this one!
- added art saving feature
- added keybinds courtesy of blueberry wolf
- made gifs more consistent
- discovered that antivirus SUCKS fuck you mcaffee
- improved preprocessing
- added manual brightness adjustment
- made stamp menu smaller for the people on crts
- changed location of saved stamps to %appdata%/local/webfishing_stamp_mod or whatever the fuck Linux ppl use (so now everything wont get deleted every update)
- faster launching executable
- added executable manager
# 2.0.1
- using... gentler compression??? because thunderstore SUCKS. and made launching it less hard to mess up
# 2.0.2 
- better dock handling system
- changed default keybind and readme
- more menu art
- fixed antivirus and better laucnh handling
- better gif handling
- faster launch times
- completely revised launching system
> future updates:
- linux version
- improved preprocessing logic
- improved ctrl z logic
- more stamps off-canvas
- add an eraser (i quit)