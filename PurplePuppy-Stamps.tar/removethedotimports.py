import os

def delete_import_files(directory):
    """
    Recursively delete all .import files in the given directory and subdirectories.
    """
    count = 0
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".import"):
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    print(f"Deleted: {file_path}")
                    count += 1
                except Exception as e:
                    print(f"Failed to delete {file_path}: {e}")
    print(f"\nTotal .import files deleted: {count}")

if __name__ == "__main__":
    current_directory = os.getcwd()  # Get the current working directory
    print(f"Scanning and deleting .import files in: {current_directory}\n")
    delete_import_files(current_directory)
